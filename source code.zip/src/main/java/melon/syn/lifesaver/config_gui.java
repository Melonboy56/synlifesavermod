package melon.syn.lifesaver;

import io.github.cottonmc.cotton.gui.GuiDescription;
import io.github.cottonmc.cotton.gui.client.CottonClientScreen;

public class config_gui extends CottonClientScreen {
    public config_gui(GuiDescription description) {
        super(description);
    }
}
